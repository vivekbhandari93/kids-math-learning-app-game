package com.example.kidslearning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import org.apache.commons.io.FileUtils;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        final Animation animShake = AnimationUtils.loadAnimation(this, R.anim.shake_horizontally);

        final Button mTablesSection = findViewById(R.id.tablesSection);
        mTablesSection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mTablesSection.startAnimation(animShake);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(HomeActivity.this, TablesActivity.class));
                        overridePendingTransition(R.anim.enter, R.anim.exit);
                        finish();
                    }
                },1000);
            }
        });

        final Button mAddSection = findViewById(R.id.addSection);
        mAddSection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAddSection.startAnimation(animShake);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(HomeActivity.this, AddActivity.class));
                        overridePendingTransition(R.anim.enter, R.anim.exit);
                        finish();
                    }
                },1000);
            }
        });

        final Button mSubSection = findViewById(R.id.subSection);
        mSubSection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mSubSection.startAnimation(animShake);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(HomeActivity.this, SubActivity.class));
                        overridePendingTransition(R.anim.enter, R.anim.exit);
                        finish();
                    }
                },1000);
            }
        });

        final Button mMulSection = findViewById(R.id.mulSection);
        mMulSection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mMulSection.startAnimation(animShake);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(HomeActivity.this, MulActivity.class));
                        overridePendingTransition(R.anim.enter, R.anim.exit);
                        finish();
                    }
                },1000);
            }
        });

        final Button mDivSection = findViewById(R.id.divSection);
        mDivSection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDivSection.startAnimation(animShake);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(HomeActivity.this, DivActivity.class));
                        overridePendingTransition(R.anim.enter, R.anim.exit);
                        finish();
                    }
                },1000);
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        FileUtils.deleteQuietly(getApplication().getCacheDir());
        overridePendingTransition(R.anim.left_to_right, R.anim.right_to_left);
    }
}
