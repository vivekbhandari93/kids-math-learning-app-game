package com.example.kidslearning;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import pl.droidsonroids.gif.GifImageView;

public class SubActivity extends AppCompatActivity {

    TextView mFirstNumber, mSecondNumber, mFirstOption, mSecondOption, mThirdOption, mForthOption, mWaitingStatus,mNext;
    ImageView mResult;
    Random random;
    List<String> list;
    Animation animShake;

    int count = 0;
    int pointsEarned = 0;
    int itemOne;

    GifImageView mBoyWaiting, mGirlWaiting;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        // setting the animation on the TextView when clicked
        animShake = AnimationUtils.loadAnimation(this, R.anim.shake_vertically);

        mFirstNumber = findViewById(R.id.firstNumber);
        mSecondNumber = findViewById(R.id.secondNumber);
        mFirstOption = findViewById(R.id.firstOption);
        mSecondOption = findViewById(R.id.secondOption);
        mThirdOption = findViewById(R.id.thirdOption);
        mForthOption = findViewById(R.id.fourthOption);
        mResult = findViewById(R.id.result);
        mWaitingStatus = findViewById(R.id.waitingStatus);
        mNext = findViewById(R.id.next);
        mBoyWaiting = findViewById(R.id.boyWaiting);
        mGirlWaiting = findViewById(R.id.girlWaiting);

        // random variable is created to generate the numbers for the game
        random = new Random();

        // list class variable is created
        list = new ArrayList<>();

        // when activity opened for the first time
        nextQuestion();


        mFirstOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mSecondOption.setClickable(false);
                mThirdOption.setClickable(false);
                mForthOption.setClickable(false);

                mFirstOption.startAnimation(animShake);
                count = 1;
                checkAnswer();
            }
        });

        mSecondOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mFirstOption.setClickable(false);
                mThirdOption.setClickable(false);
                mForthOption.setClickable(false);

                mSecondOption.startAnimation(animShake);
                count = 2;
                checkAnswer();
            }
        });

        mThirdOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mFirstOption.setClickable(false);
                mSecondOption.setClickable(false);
                mForthOption.setClickable(false);

                mThirdOption.startAnimation(animShake);
                count = 3;
                checkAnswer();
            }
        });

        mForthOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mFirstOption.setClickable(false);
                mSecondOption.setClickable(false);
                mThirdOption.setClickable(false);

                mForthOption.startAnimation(animShake);
                count = 4;
                checkAnswer();
            }
        });

        // when clicked on the next button next question is displayed
        mNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mNext.startAnimation(animShake);

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        nextQuestion();
                    }
                }, 1000);
            }
        });
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        final AlertDialog.Builder builder = new AlertDialog.Builder(SubActivity.this);
        builder.setCancelable(false);
        builder.setTitle("Quiting game!");
        builder.setIcon(R.mipmap.quit_icon);
        builder.setMessage("Are you sure?");
        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                startActivity(new Intent(SubActivity.this, HomeActivity.class));
                overridePendingTransition(R.anim.left_to_right, R.anim.right_to_left);
                finish();
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        });
        builder.show();

    }

    // when ckicked on the option it will check.
    @SuppressLint("SetTextI18n")
    private void checkAnswer() {

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                TextView toBeCheck = null;
                if (count == 1){
                    toBeCheck = mFirstOption;
                }
                else if (count == 2){
                    toBeCheck = mSecondOption;
                }
                else if (count == 3){
                    toBeCheck = mThirdOption;
                }
                else if (count == 4){
                    toBeCheck = mForthOption;
                }

                assert toBeCheck != null;
                toBeCheck.clearAnimation();

                // if its the right option then right icon will display and move to next option
                if (String.valueOf(itemOne).equals(toBeCheck.getText().toString())){

                    mResult.setImageDrawable(getDrawable(R.mipmap.right_icon));
                    mResult.setVisibility(View.VISIBLE);
                    pointsEarned += 1;
                    Snackbar.make(findViewById(android.R.id.content),"You have earned: "+pointsEarned+" points.",
                            Snackbar.LENGTH_LONG).show();
                    mWaitingStatus.setVisibility(View.GONE);
                    mBoyWaiting.setVisibility(View.GONE);
                    mGirlWaiting.setVisibility(View.GONE);
                    mResult.setAnimation(animShake);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            mResult.clearAnimation();
                            mResult.setVisibility(View.GONE);
                            mWaitingStatus.setVisibility(View.VISIBLE);
                            mBoyWaiting.setVisibility(View.VISIBLE);
                            mGirlWaiting.setVisibility(View.VISIBLE);
                            nextQuestion();
                        }
                    }, 1000);
                }
                // else it a wrong option clicked and display wrong icon
                // then move to next question
                else {

                    mResult.setImageDrawable(getDrawable(R.mipmap.wrong_icon));
                    mResult.setVisibility(View.VISIBLE);
                    mWaitingStatus.setVisibility(View.GONE);
                    mBoyWaiting.setVisibility(View.GONE);
                    mGirlWaiting.setVisibility(View.GONE);
                    mResult.setAnimation(animShake);
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            mResult.clearAnimation();
                            mResult.setVisibility(View.GONE);
                            mWaitingStatus.setVisibility(View.VISIBLE);
                            mBoyWaiting.setVisibility(View.VISIBLE);
                            mGirlWaiting.setVisibility(View.VISIBLE);
                            nextQuestion();

                        }
                    }, 1000);
                }
                mFirstOption.setClickable(true);
                mSecondOption.setClickable(true);
                mThirdOption.setClickable(true);
                mForthOption.setClickable(true);
            }
        }, 1000);
    }


    // function for creating the questions
    private void nextQuestion() {

        //clear the last items in the list before adding the new ones
        list.clear();

        // setting the first operand
        int first = random.nextInt(100);

        // setting the second oprand
        int second = random.nextInt(100);


        if (first >= second){
            itemOne = first - second;
            mFirstNumber.setText(String.valueOf(first));
            mSecondNumber.setText(String.valueOf(second));
        }
        else {
            itemOne = second - first;
            mFirstNumber.setText(String.valueOf(second));
            mSecondNumber.setText(String.valueOf(first));
        }

        // to store items in the list
        int itemTwo = random.nextInt(100);
        int itemThree = random.nextInt(100);
        int itemFourth = random.nextInt(100);
        list.add(String.valueOf(itemOne));
        list.add(String.valueOf(itemTwo));
        list.add(String.valueOf(itemThree));
        list.add(String.valueOf(itemFourth));

        // shuffle the options in the list every time
        Collections.shuffle(list);

        // setting the options to choose right answer
        mFirstOption.setText(list.get(0));
        mSecondOption.setText(list.get(1));
        mThirdOption.setText(list.get(2));
        mForthOption.setText(list.get(3));

        mNext.clearAnimation();
    }
}
